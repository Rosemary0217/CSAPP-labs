/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_366(unsigned *p)
{
    *p = 2428995944U;
}

unsigned addval_462(unsigned x)
{
    return x + 3281293400U;
}

void setval_422(unsigned *p)
{
    *p = 3284633928U;
}

void setval_219(unsigned *p)
{
    *p = 3277378200U;
}

void setval_246(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_147()
{
    return 3347646586U;
}

unsigned addval_385(unsigned x)
{
    return x + 3281016832U;
}

void setval_107(unsigned *p)
{
    *p = 2455248180U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_372(unsigned x)
{
    return x + 3380139657U;
}

void setval_294(unsigned *p)
{
    *p = 2093471369U;
}

void setval_155(unsigned *p)
{
    *p = 3286272344U;
}

unsigned addval_245(unsigned x)
{
    return x + 3223374473U;
}

unsigned getval_483()
{
    return 3252717896U;
}

void setval_231(unsigned *p)
{
    *p = 3674784137U;
}

void setval_486(unsigned *p)
{
    *p = 3682912905U;
}

unsigned getval_210()
{
    return 3375421065U;
}

unsigned addval_229(unsigned x)
{
    return x + 3529556361U;
}

unsigned getval_301()
{
    return 3525367433U;
}

void setval_459(unsigned *p)
{
    *p = 3524837769U;
}

void setval_186(unsigned *p)
{
    *p = 3232022921U;
}

unsigned addval_395(unsigned x)
{
    return x + 3525367432U;
}

unsigned getval_425()
{
    return 3383020169U;
}

void setval_417(unsigned *p)
{
    *p = 3758704799U;
}

unsigned getval_113()
{
    return 2831401355U;
}

unsigned getval_145()
{
    return 2464188744U;
}

unsigned addval_191(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_423(unsigned x)
{
    return x + 3523267209U;
}

unsigned addval_491(unsigned x)
{
    return x + 2495711676U;
}

void setval_222(unsigned *p)
{
    *p = 3221804681U;
}

void setval_232(unsigned *p)
{
    *p = 3767093448U;
}

unsigned getval_201()
{
    return 3525362057U;
}

unsigned getval_269()
{
    return 3523791489U;
}

unsigned getval_299()
{
    return 2429979634U;
}

unsigned addval_479(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_466()
{
    return 2425411273U;
}

unsigned addval_154(unsigned x)
{
    return x + 3223896457U;
}

void setval_159(unsigned *p)
{
    *p = 3284797712U;
}

unsigned addval_414(unsigned x)
{
    return x + 3525364233U;
}

void setval_484(unsigned *p)
{
    *p = 2464188744U;
}

unsigned getval_284()
{
    return 3348155017U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
